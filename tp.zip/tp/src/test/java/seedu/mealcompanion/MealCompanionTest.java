package seedu.mealcompanion;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class MealCompanionTest {
    @Test
    public void sampleTest() {
        assertTrue(true);
    }
}
