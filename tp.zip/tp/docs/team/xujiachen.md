# Jia Chen - Project Portfolio Page

## Overview
I have changed my language setting

### Summary of Contributions
I love u Ethan